"""
Lambda function entry points
"""
