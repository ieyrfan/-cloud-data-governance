"""
Shared utility functions
"""
